#!/bin/bash
rep() {
  local out=$1 in=$2 data
  data=${in//&nbsp;/ }
  data=${data//&t;/$'\t'}
  data=${data//&nl;/$'\n'}
  printf -v "$out" %s "$data"
}

rep ONE "$1"
rep TWO "$2"
rep FIVE "$5"
rep SIX "$6"
rep SEVEN "$7"

if [ "$SEVEN" = "" ]
then
    cd "$SIX"
    th sample.lua -checkpoint cv/"$ONE"/"$TWO" -length $3 -temperature $4 -sample 1 > samples/"$ONE"/Sample-$5.txt
else
    cd "$SEVEN"
    th sample.lua -checkpoint cv/"$ONE"/"$TWO" -length $3 -temperature $4 -sample 1 -start_text "$FIVE" > samples/"$ONE"/Sample-$6.txt
fi
