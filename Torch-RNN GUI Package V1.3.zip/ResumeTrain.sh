#!/bin/bash
rep() {
  local out=$1 in=$2 data
  data=${in//&nbsp;/ }
  data=${data//&t;/$'\t'}
  data=${data//&nl;/$'\n'}
  printf -v "$out" %s "$data"
}

rep ONE "$1"
rep TWO "$2"
rep FIVE "$5"

cd "$FIVE"
th train.lua -input_h5 processeddata/"$ONE"/"$ONE".h5 -input_json processeddata/"$ONE"/"$ONE".json -checkpoint_name cv/"$ONE"/checkpoint -init_from cv/"$ONE"/"$TWO" -reset_iterations 0 -max_epochs $3 -num_layers $4
