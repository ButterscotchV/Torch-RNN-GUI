#!/bin/bash
source .env/bin/activate
java -jar "Torch-RNN GUI.jar"
deactivate
