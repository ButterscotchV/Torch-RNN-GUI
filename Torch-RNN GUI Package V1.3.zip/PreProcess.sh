#!/bin/bash
rep() {
  local out=$1 in=$2 data
  data=${in//&nbsp;/ }
  data=${data//&t;/$'\t'}
  data=${data//&nl;/$'\n'}
  printf -v "$out" %s "$data"
}

rep ONE "$1"
rep TWO "$2"
rep THREE "$3"

cd "$THREE"

python scripts/preprocess.py \
  --input_txt "$ONE" \
  --output_h5 processeddata/"$TWO"/"$TWO".h5 \
  --output_json processeddata/"$TWO"/"$TWO".json
